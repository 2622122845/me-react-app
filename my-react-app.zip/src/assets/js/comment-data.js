export let yxlmCommentData = [{
    auther: "英雄联盟",
    content: "1346"
}, {
    auther: "123",
    Content: "1346"
}, {
    auther: "123",
    content: "1346"
}, {
    auther: "123",
    content: "1346"
}]
export let wzryCommentData = [{
    "auther": "wary", "content": "wary",
    "date": "2021-4-11"
},
{ "auther": "4567", "content": "123", "date": "1233" }]