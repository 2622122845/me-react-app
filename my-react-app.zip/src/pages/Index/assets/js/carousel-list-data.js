export let carouselListData = [
    {
        img: 'http://game.gtimg.cn/images/yxzj/img201606/skin/hero-info/146/146-bigskin-4.jpg',
        alt: ''
    }, {
        img: 'http://game.gtimg.cn/images/yxzj/img201606/skin/hero-info/513/513-bigskin-2.jpg',
        alt: ''
    }, {
        img: 'http://game.gtimg.cn/images/yxzj/img201606/skin/hero-info/176/176-bigskin-2.jpg',
        alt: ''
    }
]
