
import React from 'react'
import Classify from './children/Clssify';

export default class Soft extends React.Component {
    render() {
        return (
            <div>
                <Classify />
            </div>
        )
    }
}