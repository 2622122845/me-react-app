import React from 'react';

export default class Classify extends React.Component {
    render() {
        return (
            <div className='classify'>
                <ul>
                    <li className='classify-check'><a href="www.baidu.com">用户登录</a></li>
                    <li><a href='www.baidu.com'>软件</a></li>
                    <li><a href='www.baidu.com'>游戏</a></li>
                    <li><a href='www.baidu.com'>登录</a></li>
                    <li><a href='www.baidu.com'>软件</a></li>
                    <li><a href='www.baidu.com'>游戏</a></li>
                    <li><a href='www.baidu.com'>用户登录</a></li>
                    <li><a href='www.baidu.com'>软件</a></li>
                    <li><a href='www.baidu.com'>游戏</a></li>
                    <li><a href='www.baidu.com'>登录</a></li>
                    <li><a href='www.baidu.com'>软件</a></li>
                    <li><a href='www.baidu.com'>游戏</a></li>
                    <li><a href='www.baidu.com'>登录</a></li>
                </ul>
            </div>
        )
    }
}