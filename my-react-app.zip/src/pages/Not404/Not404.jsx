import React from 'react'

export default class Soft extends React.Component {
    render() {
        return (
            <div>
                404
            </div>
        )
    }
}