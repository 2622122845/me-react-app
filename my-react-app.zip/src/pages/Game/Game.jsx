import React from 'react'
import CardO from './children/CardO';

export default class Game extends React.Component {
    render() {
        return (
            <div>
                <CardO/>
            </div>
        )
    }
}