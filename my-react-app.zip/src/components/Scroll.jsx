import React from 'react'
import { BackTop } from 'antd';
export default class Scroll extends React.Component {
    render() {
        return (
            <BackTop>
                <div className='back-top'>返回顶部</div>
            </BackTop >
        )
    }
}

