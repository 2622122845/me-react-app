import React from 'react';
export default class Detail extends React.Component{
    render(){
        return (
            <div>
                13
            </div>
        )
    }
}